import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';

/// Set to true after you buy the Apple Developer account and finish iOS setup.
const bool kEnableIosPush = false;

@pragma('vm:entry-point')
Future<void> firebaseBackgroundHandler(RemoteMessage message) async {
  // Top-level function. Keep it light.
}

class PushService {
  static final _fcm = FirebaseMessaging.instance;
  static final _local = FlutterLocalNotificationsPlugin();

  static const _channel = AndroidNotificationChannel('high_importance_channel', 'High Importance Notifications', importance: Importance.high);

  static bool get _enabled => defaultTargetPlatform == TargetPlatform.android || (defaultTargetPlatform == TargetPlatform.iOS && kEnableIosPush);

  static Future<void> init() async {
    if (!_enabled) {
      debugPrint('Push disabled on this platform.');
      return;
    }

    try {
      await _fcm.requestPermission(alert: true, badge: true, sound: true);
      await _fcm.setForegroundNotificationPresentationOptions(alert: true, badge: true, sound: true);

      await _local.initialize(
        settings: const InitializationSettings(
          android: AndroidInitializationSettings('@mipmap/ic_launcher'),
          iOS: DarwinInitializationSettings(requestAlertPermission: false, requestBadgePermission: false, requestSoundPermission: false),
        ),
      );

      await _local.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>()?.createNotificationChannel(_channel);

      // Foreground messages (Android doesn't display them by itself)
      FirebaseMessaging.onMessage.listen((m) {
        final n = m.notification;
        if (n != null && defaultTargetPlatform == TargetPlatform.android) {
          _local.show(
            id: n.hashCode,
            title: n.title,
            body: n.body,
            notificationDetails: NotificationDetails(
              android: AndroidNotificationDetails(_channel.id, _channel.name, importance: Importance.high, priority: Priority.high),
            ),
          );
        }
      });

      FirebaseMessaging.onMessageOpenedApp.listen((m) {
        // navigate using m.data
      });
      final initial = await _fcm.getInitialMessage();
      if (initial != null) {
        // navigate using initial.data
      }

      await _printToken();
      _fcm.onTokenRefresh.listen((t) {
        debugPrint('FCM TOKEN REFRESHED: $t');
        // send to backend
      });
    } catch (e) {
      debugPrint('PushService init error: $e');
    }
  }

  static Future<void> _printToken() async {
    try {
      if (defaultTargetPlatform == TargetPlatform.iOS) {
        String? apns;
        for (var i = 0; i < 10 && apns == null; i++) {
          apns = await _fcm.getAPNSToken();
          if (apns == null) {
            await Future.delayed(const Duration(milliseconds: 500));
          }
        }
        if (apns == null) {
          debugPrint('APNs token not available.');
          return;
        }
      }
      final token = await _fcm.getToken();
      debugPrint('FCM TOKEN: $token');
    } catch (e) {
      debugPrint('FCM token error: $e');
    }
  }
}
