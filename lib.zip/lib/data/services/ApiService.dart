import 'dart:io';

import 'package:get/get.dart';

import 'auth_service.dart';

class ApiService extends GetConnect {
  @override
  void onInit() {
    httpClient.baseUrl = 'http://192.168.0.141:5200';
    httpClient.timeout = const Duration(seconds: 20);

    httpClient.addRequestModifier<dynamic>((request) {
      request.headers['Content-Type'] = 'application/json';
      request.headers['Accept'] = 'application/json';

      final token = Get.find<AuthService>().token;
      if (token != null && token.isNotEmpty) {
        request.headers['Authorization'] = 'Bearer $token';
      }
      return request;
    });

    super.onInit();
  }

  // ---- Auth ----

  Future<Response> sendOtp(String phoneNumber) {
    return post('/api/v1/driver/send', {"phoneNumber": phoneNumber});
  }

  Future<Response> verifyOtp({required String id, required String otp}) {
    return post('/api/v1/driver/verify', {"_id": id, "otp": otp});
  }

  // ---- Dashboard ----

  Future<Response> getDashboard() {
    return get('/api/v1/driver/dashboard');
  }

  // ---- Profile ----

  Future<Response> getProfile() {
    return get('/api/v1/driver/profile');
  }

  Future<Response> updateProfileImage(File imageFile) {
    final form = FormData({'profileImage': MultipartFile(imageFile, filename: imageFile.path.split(Platform.pathSeparator).last)});
    // Explicitly clear Content-Type so GetConnect/http sets the correct
    // multipart/form-data boundary itself instead of inheriting the JSON one.
    return put('/api/v1/driver/profile/update', form, contentType: 'multipart/form-data');
  }

  /// status must be one of: available, on_trip, off_duty, inactive, offline
  Future<Response> updateDriverStatus(String status) {
    return patch('/api/v1/driver/profile/status?status=$status', {});
  }

  // ---- Shipments / Trips ----

  Future<Response> getShipment() {
    return get('/api/v1/driver/shipment/get');
  }

  Future<Response> getAllShipments() {
    return get('/api/v1/driver/shipment/getall');
  }

  /// status must be one of: confirmed, rejected, pickup_done, in_transit, delivered, completed
  Future<Response> updateShipmentStatus({required String id, required String status, String? reason}) {
    final body = {"status": status, if (reason != null && reason.isNotEmpty) "reason": reason};
    return patch('/api/v1/driver/shipment/status?id=$id', body);
  }

  Future<Response> getShipmentTracking(String id) {
    return get('/api/v1/driver/shipment/tracking?id=$id');
  }

  Future<Response> getShipmentRoute(String id) {
    return get('/api/v1/driver/shipment/route?id=$id');
  }

  // ---- Proof of Delivery ----

  Future<Response> uploadSignature({required String shipmentId, required String image}) {
    return post('/api/v1/driver/signature/upload', {"shipmentId": shipmentId, "image": image});
  }

  Future<Response> getSignatures({required String shipmentId}) {
    return get('/api/v1/driver/signature/view?shipmentId=$shipmentId');
  }

  Future<Response> createPOD({required String shipmentId, required List<String> images}) {
    return post('/api/v1/driver/pod/create', {"shipmentId": shipmentId, "images": images});
  }

  Future<Response> getPOD(String id) {
    return get('/api/v1/driver/pod/get?_id=$id');
  }

  // ---- Contact ----

  Future<Response> getContact(String shipmentId) {
    return get('/api/v1/driver/contact/get?shipmentId=$shipmentId');
  }

  Future<Response> getSupportContact() {
    return get('/api/v1/driver/contact/support');
  }

  // ---- Location ----

  Future<Response> updateDriverLocation({required double latitude, required double longitude}) {
    return patch('/api/v1/driver/location/update', {"latitude": latitude, "longitude": longitude});
  }
}
